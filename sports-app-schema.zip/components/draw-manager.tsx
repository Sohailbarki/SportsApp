"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { generateRoundRobin, generateSingleElimination } from "@/lib/draw-generator"
import { MatchCard, type Match } from "./match-card"
import { StandingsTable } from "./standings-table"
import { Trophy, AlertTriangle, RefreshCw } from "lucide-react"
import { updateDrawData } from "@/app/events/actions"
import { useToast } from "./ui/use-toast"

type Participant = { id: string; name: string }
type Standing = { name: string; played: number; wins: number; draws: number; losses: number; points: number }
type Round = Match[]

// This is the object we'll save to the database
type DrawData = {
  type: string
  pointsConfig: { win: number; draw: number; lose: number }
  matches?: Match[]
  rounds?: Round[]
  participantCount: number
}

interface DrawManagerProps {
  eventId: string
  participants: Participant[]
  initialDrawData: DrawData | null
}

export function DrawManager({ eventId, participants, initialDrawData }: DrawManagerProps) {
  const { toast } = useToast()
  const [drawData, setDrawData] = useState<DrawData | null>(initialDrawData)
  const [isSaving, setIsSaving] = useState(false)

  const participantListChanged = initialDrawData && initialDrawData.participantCount !== participants.length

  const handleSaveDraw = async (dataToSave: DrawData | null) => {
    setIsSaving(true)
    const result = await updateDrawData(eventId, dataToSave)
    if (result.error) {
      toast({ variant: "destructive", title: "Save Failed", description: "Could not save the draw state." })
    }
    setIsSaving(false)
  }

  const handleGenerateDraw = () => {
    const type = drawData?.type
    if (!type) return

    const newDrawData: DrawData = {
      type,
      pointsConfig: drawData?.pointsConfig || { win: 3, draw: 1, lose: 0 },
      participantCount: participants.length,
    }

    if (type === "round-robin") {
      newDrawData.matches = generateRoundRobin(participants)
    } else if (type === "single-elimination") {
      newDrawData.rounds = [generateSingleElimination(participants)]
    }

    setDrawData(newDrawData)
    handleSaveDraw(newDrawData)
  }

  const handleUpdate = (updatedState: Partial<DrawData>) => {
    const newState = { ...drawData, ...updatedState } as DrawData
    setDrawData(newState)
    handleSaveDraw(newState)
  }

  const handleRoundRobinUpdate = (matchIndex: number, result: { winner: Participant | null; isDraw: boolean }) => {
    if (!drawData?.matches) return
    const updatedMatches = [...drawData.matches]
    updatedMatches[matchIndex] = { ...updatedMatches[matchIndex], winner: result.winner?.name, isDraw: result.isDraw }
    handleUpdate({ matches: updatedMatches })
  }

  const handleKnockoutUpdate = (roundIndex: number, matchIndex: number, result: { winner: Participant | null }) => {
    if (!result.winner || !drawData?.rounds) return
    const newRounds = [...drawData.rounds]
    newRounds[roundIndex][matchIndex].winner = result.winner.name
    const currentRound = newRounds[roundIndex]
    const isRoundComplete = currentRound.every((m) => m.winner || m.p2.name === "BYE")
    if (isRoundComplete) {
      const winners = currentRound
        .map((m) => (m.p2.name === "BYE" ? m.p1 : participants.find((p) => p.name === m.winner!)))
        .filter(Boolean) as Participant[]
      if (winners.length > 1) {
        newRounds.push(generateSingleElimination(winners, true))
      }
    }
    handleUpdate({ rounds: newRounds })
  }

  const handleResetDraw = () => {
    setDrawData(null)
    handleSaveDraw(null)
  }

  const standings = useMemo(() => {
    if (drawData?.type !== "round-robin" || !drawData.matches) return []
    const newStandings = participants.map((p) => {
      const stats = { name: p.name, played: 0, wins: 0, draws: 0, losses: 0, points: 0 }
      drawData.matches!.forEach((m) => {
        if ((m.p1.name === p.name || m.p2.name === p.name) && (m.winner || m.isDraw)) {
          stats.played++
          if (m.isDraw) {
            stats.draws++
            stats.points += drawData.pointsConfig.draw
          } else if (m.winner === p.name) {
            stats.wins++
            stats.points += drawData.pointsConfig.win
          } else {
            stats.losses++
            stats.points += drawData.pointsConfig.lose
          }
        }
      })
      return stats
    })
    return newStandings
  }, [drawData, participants])

  const tournamentWinner = useMemo(() => {
    const rounds = drawData?.rounds
    if (rounds && rounds.length > 0) {
      const lastRound = rounds[rounds.length - 1]
      if (lastRound.length === 1 && lastRound[0].winner) return lastRound[0].winner
    }
    return null
  }, [drawData])

  if (participantListChanged) {
    return (
      <Card className="border-orange-500 bg-orange-400/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle /> Participant List Changed
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            New participants have joined or left since the draw was created. To include them, you must reset the current
            draw.
          </p>
          <Button onClick={handleResetDraw} className="w-full">
            <RefreshCw className="mr-2 h-4 w-4" /> Reset Draw
          </Button>
        </CardContent>
      </Card>
    )
  }

  if (!drawData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Create Draw</CardTitle>
          <CardDescription>Select a tournament format.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <RadioGroup
            onValueChange={(type) =>
              setDrawData({ type, pointsConfig: { win: 3, draw: 1, lose: 0 }, participantCount: 0 })
            }
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="round-robin" id="rr" />
              <Label htmlFor="rr">Round Robin</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="single-elimination" id="se" />
              <Label htmlFor="se">Knockout</Label>
            </div>
          </RadioGroup>
          <Button onClick={handleGenerateDraw} disabled={!drawData?.type || participants.length < 2} className="w-full">
            {participants.length < 2 ? "Need at least 2 participants" : "Generate Draw"}
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {drawData.type === "round-robin" && drawData.matches && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Matches</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {drawData.matches.map((match, index) => (
                <MatchCard
                  key={index}
                  match={match}
                  onUpdate={(result) => handleRoundRobinUpdate(index, result)}
                  allowDraws={true}
                />
              ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Standings</CardTitle>
            </CardHeader>
            <CardContent>
              <StandingsTable standings={standings} />
            </CardContent>
          </Card>
        </>
      )}
      {drawData.type === "single-elimination" && drawData.rounds && (
        <div className="space-y-4">
          {drawData.rounds.map((round, roundIndex) => (
            <Card key={roundIndex}>
              <CardHeader>
                <CardTitle>
                  {round.length === 1 ? "Final" : round.length === 2 ? "Semi-Finals" : `Round ${roundIndex + 1}`}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {round.map((match, matchIndex) => (
                  <MatchCard
                    key={matchIndex}
                    match={match}
                    onUpdate={(result) => handleKnockoutUpdate(roundIndex, matchIndex, result)}
                    allowDraws={false}
                  />
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      {tournamentWinner && (
        <Card className="bg-yellow-400/20 border-yellow-500">
          <CardHeader className="flex-row items-center gap-4">
            <Trophy className="w-10 h-10 text-yellow-600" />
            <div>
              <CardTitle>Tournament Champion!</CardTitle>
              <CardDescription className="text-2xl font-bold text-yellow-700">{tournamentWinner}</CardDescription>
            </div>
          </CardHeader>
        </Card>
      )}
    </div>
  )
}
