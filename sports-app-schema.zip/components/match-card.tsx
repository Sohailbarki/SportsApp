import { Button } from './ui/button';
import { cn } from '@/lib/utils';

type Participant = { id: string; name: string };
export type Match = {
  p1: Participant;
  p2: Participant;
  winner?: string | null; // name of the winner
  isDraw?: boolean;
};

interface MatchCardProps {
  match: Match;
  onUpdate: (result: { winner: Participant | null; loser: Participant | null; isDraw: boolean }) => void;
  allowDraws: boolean;
}

export function MatchCard({ match, onUpdate, allowDraws }: MatchCardProps) {
  const handleResult = (winner: Participant | null, isDraw = false) => {
    let loser: Participant | null = null;
    if (winner) {
      loser = winner.id === match.p1.id ? match.p2 : match.p1;
    }
    onUpdate({ winner, loser, isDraw });
  };

  const getButtonClass = (participantName: string) => {
    if (!match.winner && !match.isDraw) return "bg-muted hover:bg-muted/80 text-muted-foreground";
    if (match.isDraw) return "bg-blue-500/20 text-blue-700 dark:text-blue-400";
    if (match.winner === participantName) return "bg-green-500/20 text-green-700 dark:text-green-400 font-bold";
    return "bg-red-500/20 text-red-700 dark:text-red-400";
  };

  return (
    <div className="flex items-center justify-between p-2 border rounded-md gap-2">
      <Button onClick={() => handleResult(match.p1)} className={cn("flex-1 justify-start", getButtonClass(match.p1.name))}>
        {match.p1.name}
      </Button>
      
      {allowDraws ? (
        <Button variant="ghost" size="sm" onClick={() => handleResult(null, true)} className={cn(match.isDraw && "bg-blue-500/20")}>
          Draw
        </Button>
      ) : (
        <span className="text-sm text-muted-foreground">vs</span>
      )}

      <Button onClick={() => handleResult(match.p2)} className={cn("flex-1 justify-end", getButtonClass(match.p2.name))}>
        {match.p2.name}
      </Button>
    </div>
  );
}
