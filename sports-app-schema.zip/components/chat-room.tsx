"use client";

import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send } from 'lucide-react';
import { mockUser } from '@/lib/mock-data';

const initialMessages = [
  { id: 1, user: { name: 'Alice', avatar: '/placeholder.svg?height=40&width=40' }, text: 'Hey everyone, excited for the tournament!', timestamp: '10:30 AM' },
  { id: 2, user: { name: 'Bob', avatar: '/placeholder.svg?height=40&width=40' }, text: 'Me too! Anyone need a partner?', timestamp: '10:31 AM' },
];

export function ChatRoom() {
  const [messages, setMessages] = useState(initialMessages);
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() === '') return;

    const message = {
      id: messages.length + 1,
      user: mockUser,
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([...messages, message]);
    setNewMessage('');
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(msg => {
          const isCurrentUser = msg.user.name === mockUser.name;
          return (
            <div key={msg.id} className={`flex items-end gap-2 ${isCurrentUser ? 'justify-end' : ''}`}>
              {!isCurrentUser && <Avatar><AvatarImage src={msg.user.avatar || "/placeholder.svg"} /><AvatarFallback>{msg.user.name.charAt(0)}</AvatarFallback></Avatar>}
              <div className={`rounded-lg p-3 max-w-xs lg:max-w-md ${isCurrentUser ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                {!isCurrentUser && <p className="text-xs font-semibold mb-1">{msg.user.name}</p>}
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 text-right ${isCurrentUser ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{msg.timestamp}</p>
              </div>
              {isCurrentUser && <Avatar><AvatarImage src={msg.user.avatar || "/placeholder.svg"} /><AvatarFallback>{mockUser.name.charAt(0)}</AvatarFallback></Avatar>}
            </div>
          );
        })}
      </div>
      <div className="p-4 border-t bg-background">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1"
          />
          <Button type="submit" size="icon"><Send className="h-4 w-4" /></Button>
        </form>
      </div>
    </div>
  );
}
