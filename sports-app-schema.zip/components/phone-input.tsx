"use client"

import { Label } from "./ui/label"
import { Input } from "./ui/input"
import { Button } from "./ui/button"
import { useFormStatus } from "react-dom"

function SubmitButton() {
  const { pending } = useFormStatus()
  return (
    <Button type="submit" disabled={pending} className="w-full">
      {pending ? "Adding..." : "Add Player"}
    </Button>
  )
}

// Simplified phone input without external dependencies that might cause conflicts
export function AddPlayerForm() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
      <div className="space-y-2">
        <Label htmlFor="name">Player Name</Label>
        <Input id="name" name="name" placeholder="e.g., Alex Smith" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number</Label>
        <Input id="phone" name="phone" type="tel" placeholder="+1 (555) 123-4567" required />
      </div>
      <SubmitButton />
    </div>
  )
}
