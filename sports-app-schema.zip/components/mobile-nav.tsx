import Link from "next/link";
import { Home, Bell, User, CalendarPlus } from 'lucide-react';

export function MobileNav() {
  return (
    <div className="fixed bottom-0 left-0 z-50 w-full h-16 bg-background border-t">
      <div className="grid h-full max-w-lg grid-cols-4 mx-auto font-medium">
        <Link href="/dashboard" className="inline-flex flex-col items-center justify-center px-5 hover:bg-muted text-primary">
          <Home className="w-5 h-5 mb-1" />
          <span className="text-sm">Home</span>
        </Link>
        <Link href="/events/create" className="inline-flex flex-col items-center justify-center px-5 hover:bg-muted text-muted-foreground">
          <CalendarPlus className="w-5 h-5 mb-1" />
          <span className="text-sm">Create</span>
        </Link>
        <Link href="/notifications" className="inline-flex flex-col items-center justify-center px-5 hover:bg-muted text-muted-foreground">
          <Bell className="w-5 h-5 mb-1" />
          <span className="text-sm">Alerts</span>
        </Link>
        <Link href="/profile" className="inline-flex flex-col items-center justify-center px-5 hover:bg-muted text-muted-foreground">
          <User className="w-5 h-5 mb-1" />
          <span className="text-sm">Profile</span>
        </Link>
      </div>
    </div>
  );
}
