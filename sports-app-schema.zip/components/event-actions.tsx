"use client"

import { Button } from "@/components/ui/button"
import { leaveEvent, updateParticipantStatus } from "@/app/events/actions"
import { useTransition } from "react"

type Participant = {
  user_id: string
  status: "invited" | "joined" | "declined"
}

interface EventActionsProps {
  eventId: string
  userId: string
  participants: Participant[]
}

export function EventActions({ eventId, userId, participants }: EventActionsProps) {
  const [isPending, startTransition] = useTransition()

  const userParticipant = participants.find((p) => p.user_id === userId)
  const status = userParticipant?.status

  if (!userParticipant) {
    // This case shouldn't happen if the user was invited, but as a fallback:
    return <Button disabled>Not Invited</Button>
  }

  const handleJoin = () => startTransition(() => updateParticipantStatus(eventId, "joined"))
  const handleDecline = () => startTransition(() => updateParticipantStatus(eventId, "declined"))
  const handleLeave = () => startTransition(() => leaveEvent(eventId))

  return (
    <div className="flex gap-2">
      {status === "invited" && (
        <>
          <Button onClick={handleJoin} disabled={isPending} className="flex-1">
            {isPending ? "Joining..." : "Opt In"}
          </Button>
          <Button onClick={handleDecline} disabled={isPending} variant="outline" className="flex-1 bg-transparent">
            {isPending ? "Declining..." : "Opt Out"}
          </Button>
        </>
      )}
      {status === "joined" && (
        <Button onClick={handleLeave} disabled={isPending} variant="destructive" className="w-full">
          {isPending ? "Leaving..." : "Leave Event"}
        </Button>
      )}
      {status === "declined" && (
        <Button onClick={handleJoin} disabled={isPending} className="w-full">
          {isPending ? "Joining..." : "Re-join Event"}
        </Button>
      )}
    </div>
  )
}
