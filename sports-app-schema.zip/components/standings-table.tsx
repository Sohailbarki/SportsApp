import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

type Standing = {
  name: string;
  played: number;
  wins: number;
  draws: number;
  losses: number;
  points: number;
};

interface StandingsTableProps {
  standings: Standing[];
}

export function StandingsTable({ standings }: StandingsTableProps) {
  const sortedStandings = [...standings].sort((a, b) => b.points - a.points || (b.wins - a.wins));

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-[40px]">#</TableHead>
          <TableHead>Team</TableHead>
          <TableHead className="text-center">P</TableHead>
          <TableHead className="text-center">W</TableHead>
          <TableHead className="text-center">D</TableHead>
          <TableHead className="text-center">L</TableHead>
          <TableHead className="text-center">Pts</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {sortedStandings.map((team, index) => (
          <TableRow key={team.name}>
            <TableCell>{index + 1}</TableCell>
            <TableCell className="font-medium">{team.name}</TableCell>
            <TableCell className="text-center">{team.played}</TableCell>
            <TableCell className="text-center">{team.wins}</TableCell>
            <TableCell className="text-center">{team.draws}</TableCell>
            <TableCell className="text-center">{team.losses}</TableCell>
            <TableCell className="text-center font-bold">{team.points}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
