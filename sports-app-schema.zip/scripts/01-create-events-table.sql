-- Drop the table if it exists to start fresh
DROP TABLE IF EXISTS public.events;

-- Create Events table
CREATE TABLE public.events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  sport TEXT NOT NULL,
  recurrence TEXT,
  event_time TIMESTAMPTZ,
  location TEXT,
  description TEXT,
  participants JSONB, -- Storing participants as a JSON array
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Optional: Enable Row Level Security if you plan to add user auth back later
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

-- For now, allow public access for reads and writes since there's no auth
-- This policy allows anyone to read and write to the events table.
-- You would make this more secure if you re-add user authentication.
CREATE POLICY "Public access" ON public.events FOR ALL
USING (true)
WITH CHECK (true);
