-- Seed some initial sports data
INSERT INTO public.sports (name) VALUES
('Soccer'), ('Basketball'), ('Tennis'), ('Volleyball'), ('Badminton'),
('Table Tennis'), ('Cricket'), ('Rugby'), ('American Football'), ('Baseball'),
('Padel'), ('Squash'), ('Futsal'), ('Handball'), ('Water Polo');
