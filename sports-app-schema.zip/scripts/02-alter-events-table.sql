-- Add a new column to the events table to store all draw-related data as a single JSON object.
ALTER TABLE public.events
ADD COLUMN draw_data JSONB;
