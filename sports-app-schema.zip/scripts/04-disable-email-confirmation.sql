-- This script disables email confirmation for development purposes
-- Run this in your Supabase SQL Editor to allow users to sign in without email confirmation

-- Note: This is for development only. In production, you should keep email confirmation enabled.

-- You can also do this through the Supabase Dashboard:
-- 1. Go to Authentication > Settings
-- 2. Under "User Signups", toggle OFF "Enable email confirmations"

-- Alternatively, update the auth config (this requires admin access):
-- UPDATE auth.config SET enable_signup = true, enable_confirmations = false WHERE id = 1;

-- For now, let's create a simple way to manually confirm users if needed:
-- You can run this query replacing 'user@example.com' with the actual email:
-- UPDATE auth.users SET email_confirmed_at = NOW() WHERE email = 'user@example.com';
