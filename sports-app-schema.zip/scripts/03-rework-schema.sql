-- Drop existing tables to avoid conflicts and start fresh
DROP TABLE IF EXISTS public.event_participants;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.profiles;

-- 1. Create Profiles Table
-- This table stores public user data and is linked to Supabase's private auth.users table.
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT UNIQUE, -- Make phone unique to use it as a lookup key
  avatar_url TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS for Profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles are viewable by everyone." ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile." ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update their own profile." ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- 2. Create Events Table (reworked)
-- Organizer ID now links to a real user profile.
CREATE TABLE public.events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id UUID NOT NULL REFERENCES public.profiles(id),
  title TEXT NOT NULL,
  sport TEXT NOT NULL,
  recurrence TEXT,
  event_time TIMESTAMPTZ,
  location TEXT,
  description TEXT,
  draw_data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS for Events
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Events are viewable by everyone." ON public.events FOR SELECT USING (true);
CREATE POLICY "Authenticated users can create events." ON public.events FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Organizers can update their own events." ON public.events FOR UPDATE USING (auth.uid() = organizer_id);
CREATE POLICY "Organizers can delete their own events." ON public.events FOR DELETE USING (auth.uid() = organizer_id);


-- 3. Create Event Participants Junction Table
-- This is the key to linking users to events with a status.
CREATE TYPE participant_status AS ENUM ('invited', 'joined', 'declined');

CREATE TABLE public.event_participants (
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status participant_status NOT NULL DEFAULT 'invited',
  added_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (event_id, user_id)
);

-- RLS for Event Participants
ALTER TABLE public.event_participants ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Participants can be viewed by anyone." ON public.event_participants FOR SELECT USING (true);
CREATE POLICY "Organizers can add participants." ON public.event_participants FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM events WHERE events.id = event_id AND events.organizer_id = auth.uid())
);
CREATE POLICY "Users can update their own status (join/decline)." ON public.event_participants FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can leave events, organizers can remove them." ON public.event_participants FOR DELETE
  USING (auth.uid() = user_id OR EXISTS (SELECT 1 FROM events WHERE events.id = event_id AND events.organizer_id = auth.uid()));

-- Function to automatically create a profile when a new user signs up in Supabase Auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', new.phone);
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to run the function after a new user is created
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
