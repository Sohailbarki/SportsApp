import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get("code")
  const next = searchParams.get("next") ?? "/dashboard"

  if (code) {
    const supabase = createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)

    if (!error) {
      // Successful email confirmation, redirect to dashboard
      return NextResponse.redirect(`${origin}${next}`)
    } else {
      console.error("Auth callback error:", error)
      return NextResponse.redirect(`${origin}/login?message=Email confirmation failed. Please try again.`)
    }
  }

  // No code provided, redirect to login with error
  return NextResponse.redirect(`${origin}/login?message=Invalid confirmation link`)
}
