"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"

export async function login(formData: FormData) {
  const supabase = createClient()

  const data = {
    email: formData.get("email") as string,
    password: formData.get("password") as string,
  }

  // Validate input
  if (!data.email || !data.password) {
    return redirect("/login?message=Email and password are required")
  }

  const { error } = await supabase.auth.signInWithPassword(data)

  if (error) {
    console.error("Login error:", error)

    // Handle specific error cases
    if (error.message === "Email not confirmed") {
      return redirect("/login?message=Please check your email and click the confirmation link before signing in")
    }
    if (error.message === "Invalid login credentials") {
      return redirect("/login?message=Invalid email or password")
    }

    return redirect("/login?message=Could not sign in. Please try again.")
  }

  revalidatePath("/", "layout")
  redirect("/dashboard")
}

export async function signup(formData: FormData) {
  const supabase = createClient()

  const data = {
    full_name: formData.get("fullName") as string,
    email: formData.get("email") as string,
    password: formData.get("password") as string,
  }

  // Validate input
  if (!data.full_name || !data.email || !data.password) {
    return redirect("/login?message=All fields are required")
  }

  if (data.password.length < 6) {
    return redirect("/login?message=Password must be at least 6 characters")
  }

  const { data: authData, error } = await supabase.auth.signUp({
    email: data.email,
    password: data.password,
    options: {
      data: {
        full_name: data.full_name,
      },
      // For development, you can set this to skip email confirmation
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/callback`,
    },
  })

  if (error) {
    console.error("Signup error:", error)
    if (error.message.includes("already registered")) {
      return redirect("/login?message=An account with this email already exists")
    }
    return redirect("/login?message=Could not create account. Please try again.")
  }

  // Check if email confirmation is required
  if (authData.user && !authData.session) {
    return redirect("/login?message=Check your email and click the confirmation link to complete your registration")
  }

  // If no email confirmation required, redirect to dashboard
  if (authData.session) {
    revalidatePath("/", "layout")
    redirect("/dashboard")
  }

  return redirect("/login?message=Account created successfully! Please sign in.")
}

export async function resendConfirmation(formData: FormData) {
  const supabase = createClient()
  const email = formData.get("email") as string

  if (!email) {
    return redirect("/login?message=Email is required")
  }

  const { error } = await supabase.auth.resend({
    type: "signup",
    email: email,
    options: {
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/callback`,
    },
  })

  if (error) {
    console.error("Resend error:", error)
    return redirect("/login?message=Could not resend confirmation email")
  }

  return redirect("/login?message=Confirmation email sent! Check your inbox.")
}

export async function logout() {
  const supabase = createClient()
  await supabase.auth.signOut()
  revalidatePath("/", "layout")
  redirect("/login")
}
