import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"

export default async function HomePage() {
  const supabase = createClient()

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user) {
      // User is authenticated, redirect to dashboard
      redirect("/dashboard")
    } else {
      // User is not authenticated, redirect to login
      redirect("/login")
    }
  } catch (error) {
    // If there's any error with auth, redirect to login
    console.error("Auth error:", error)
    redirect("/login")
  }
}
