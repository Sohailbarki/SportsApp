import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PlusCircle, MapPin, Calendar, Users } from "lucide-react"
import Link from "next/link"
import { MobileNav } from "@/components/mobile-nav"
import { UserNav } from "@/components/user-nav"
import { getEvents } from "@/app/events/actions"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"

export default async function DashboardPage() {
  const supabase = createClient()

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      redirect("/login")
    }

    const { events } = await getEvents()

    return (
      <div className="flex min-h-screen w-full flex-col bg-muted/40">
        <header className="sticky top-0 flex h-16 items-center justify-between gap-4 border-b bg-background px-4 md:px-6">
          <div className="flex flex-col">
            <span className="text-sm text-muted-foreground">Welcome back,</span>
            <h1 className="text-xl font-semibold">{user.user_metadata?.full_name || user.email}!</h1>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/events/create">
              <Button size="sm" className="gap-1">
                <PlusCircle className="h-4 w-4" />
                Create Event
              </Button>
            </Link>
            <UserNav user={user} />
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 space-y-4 pb-20">
          <h2 className="text-lg font-semibold">Events</h2>
          {events && events.length > 0 ? (
            events.map((event) => (
              <Link href={`/events/${event.id}`} key={event.id}>
                <Card className="hover:bg-muted/50 transition-colors">
                  <CardHeader>
                    <CardTitle>{event.title}</CardTitle>
                    <CardDescription>{event.sport}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm text-muted-foreground">
                    {event.event_time && (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(event.event_time).toLocaleString()}</span>
                      </div>
                    )}
                    {event.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        <span>{event.location}</span>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4" />
                      <span>{event.participants?.length || 0} participants</span>
                    </div>
                  </CardFooter>
                </Card>
              </Link>
            ))
          ) : (
            <Card>
              <CardContent className="p-6 text-center text-muted-foreground">
                No events yet. Why not create one?
              </CardContent>
            </Card>
          )}
        </main>
        <MobileNav />
      </div>
    )
  } catch (error) {
    console.error("Dashboard error:", error)
    redirect("/login")
  }
}
