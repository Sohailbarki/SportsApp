"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { SportSelector } from "@/components/sport-selector"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/components/ui/use-toast"
import { createEvent } from "@/app/events/actions"

export default function CreateEventPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (formData: FormData) => {
    setIsSubmitting(true)

    try {
      const result = await createEvent({
        title: formData.get("title") as string,
        sport:
          formData.get("sport") === "other"
            ? (formData.get("customSport") as string)
            : (formData.get("sport") as string),
        recurrence: formData.get("recurrence") as string,
        event_time:
          formData.get("recurrence") === "one-time" ? `${formData.get("date")}T${formData.get("time")}` : null,
        location: formData.get("location") as string,
        description: formData.get("description") as string,
      })

      if (result.error) {
        throw new Error(result.error)
      }

      toast({
        title: "Event Created!",
        description: "Your event has been successfully created.",
      })

      router.push("/dashboard")
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Creation Failed",
        description: error.message || "Please review the form and try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-muted/40">
      <header className="sticky top-0 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Link href="/dashboard">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-xl font-semibold">Create New Event</h1>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <form action={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Event Details</CardTitle>
              <CardDescription>Fill in the information for your new event.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Event Title</Label>
                <Input id="title" name="title" placeholder="e.g., Weekly Padel Match" required />
              </div>

              <div className="space-y-2">
                <Label>Sport</Label>
                <SportSelector value="" onChange={() => {}} />
                <input type="hidden" name="sport" id="sport-hidden" />
              </div>

              <div className="space-y-3">
                <Label>Frequency</Label>
                <RadioGroup name="recurrence" defaultValue="one-time" className="flex flex-wrap gap-x-6 gap-y-2">
                  {["One-time", "Ongoing", "Weekly", "Monthly"].map((freq) => (
                    <div key={freq} className="flex items-center space-x-2">
                      <RadioGroupItem value={freq.toLowerCase()} id={`r-${freq.toLowerCase()}`} />
                      <Label htmlFor={`r-${freq.toLowerCase()}`}>{freq}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" name="date" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <Input id="time" name="time" type="time" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" name="location" placeholder="e.g., Central Park Courts" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" name="description" placeholder="Any additional details about the event." />
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Creating..." : "Create Event"}
              </Button>
            </CardContent>
          </Card>
        </form>
      </main>
    </div>
  )
}
