import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Calendar, MapPin, Trophy, MessageSquare, Info, AlertTriangle, UserCheck, UserX } from "lucide-react"
import Link from "next/link"
import { ChatRoom } from "@/components/chat-room"
import { DrawManager } from "@/components/draw-manager"
import { getEventWithParticipants, addPlayerToEvent } from "@/app/events/actions"
import { EventActions } from "@/components/event-actions"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { createClient } from "@/lib/supabase/server"
import { AddPlayerForm } from "@/components/phone-input"

export default async function EventDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  const { event } = await getEventWithParticipants(params.id)

  if (!event) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center">
        <AlertTriangle className="w-16 h-16 text-destructive mb-4" />
        <h1 className="text-2xl font-bold">Event Not Found</h1>
        <p className="text-muted-foreground">The event you are looking for does not exist.</p>
        <Link href="/dashboard" className="mt-6">
          <Button>Go to Dashboard</Button>
        </Link>
      </div>
    )
  }

  const isOrganizer = user?.id === event.organizer_id
  const participants = event.participants || []
  const joinedParticipants = participants
    .filter((p: any) => p.status === "joined")
    .map((p: any) => ({ id: p.user_id, name: p.profile.full_name || "Unnamed Player" }))

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6 z-10">
        <Link href="/dashboard">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-xl font-semibold truncate">{event.title}</h1>
      </header>
      <main className="flex-1">
        <Tabs defaultValue="details" className="w-full">
          <TabsList className="grid w-full grid-cols-3 sticky top-16 bg-background z-10">
            <TabsTrigger value="details">
              <Info className="h-4 w-4 mr-2" />
              Details
            </TabsTrigger>
            <TabsTrigger value="chat">
              <MessageSquare className="h-4 w-4 mr-2" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="draw">
              <Trophy className="h-4 w-4 mr-2" />
              Draw
            </TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="p-4 md:p-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{event.sport}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {event.event_time && (
                  <div className="flex items-center gap-3">
                    <Calendar className="h-5 w-5 text-muted-foreground" />
                    <span>{new Date(event.event_time).toLocaleString()}</span>
                  </div>
                )}
                {event.location && (
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <span>{event.location}</span>
                  </div>
                )}
                {event.description && <p className="text-muted-foreground pt-2">{event.description}</p>}
                {!isOrganizer && user && (
                  <EventActions eventId={event.id} userId={user.id} participants={participants} />
                )}
              </CardContent>
            </Card>
            {isOrganizer && (
              <Card>
                <CardHeader>
                  <CardTitle>Add New Player</CardTitle>
                </CardHeader>
                <CardContent>
                  <form action={addPlayerToEvent}>
                    <input type="hidden" name="eventId" value={event.id} />
                    <AddPlayerForm />
                  </form>
                </CardContent>
              </Card>
            )}
            <Card>
              <CardHeader>
                <CardTitle>Participants</CardTitle>
              </CardHeader>
              <CardContent>
                {participants.length > 0 ? (
                  <div className="space-y-2">
                    {participants.map((p: any) => (
                      <div key={p.user_id} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>{p.profile.full_name?.charAt(0) || "?"}</AvatarFallback>
                          </Avatar>
                          <span>{p.profile.full_name || "Invited Player"}</span>
                        </div>
                        {p.status === "joined" && <UserCheck className="h-5 w-5 text-green-500" title="Joined" />}
                        {p.status === "declined" && <UserX className="h-5 w-5 text-red-500" title="Declined" />}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No players have been added yet.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="chat" className="h-[calc(100vh-128px)]">
            <ChatRoom />
          </TabsContent>

          <TabsContent value="draw" className="p-4 md:p-6">
            {isOrganizer ? (
              <DrawManager eventId={event.id} participants={joinedParticipants} initialDrawData={event.draw_data} />
            ) : (
              <p>The organizer has not generated the draw yet.</p>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
