"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"
import type { E164Number } from "libphonenumber-js/core"

export async function createEvent(eventData: any) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { error: "You must be logged in to create an event." }

  const { error } = await supabase.from("events").insert([{ ...eventData, organizer_id: user.id }])
  if (error) return { error: `Database error: ${error.message}` }

  revalidatePath("/dashboard")
  return { success: true }
}

export async function getEvents() {
  const supabase = createClient()
  const { data: events, error } = await supabase
    .from("events")
    .select("*, organizer:profiles(full_name)")
    .order("created_at", { ascending: false })

  if (error) return { events: [] }
  return { events: events || [] }
}

export async function getEventWithParticipants(id: string) {
  const supabase = createClient()
  const { data, error } = await supabase
    .from("events")
    .select("*, participants:event_participants(*, profile:profiles(*))")
    .eq("id", id)
    .single()

  if (error) return { event: null }
  return { event: data }
}

export async function addPlayerToEvent(formData: FormData) {
  const supabase = createClient()

  const eventId = formData.get("eventId") as string
  const playerName = formData.get("name") as string
  const playerPhone = formData.get("phone") as E164Number

  if (!eventId || !playerName || !playerPhone) {
    return { error: "Missing required form data." }
  }

  // 1. Check if a profile with this phone number already exists
  let { data: profile } = await supabase.from("profiles").select("id").eq("phone", playerPhone).single()

  // 2. If not, create a placeholder auth user and profile
  if (!profile) {
    const { data: newUser, error: userError } = await supabase.auth.admin.createUser({
      phone: playerPhone,
      phone_confirm: true, // Mark as confirmed since the organizer is adding them
      user_metadata: { full_name: playerName },
    })
    if (userError) return { error: `Could not create user: ${userError.message}` }
    // The trigger will create the profile, so we just need the ID
    profile = { id: newUser.user.id }
  }

  // 3. Add the user to the event_participants table
  const { error: participantError } = await supabase
    .from("event_participants")
    .insert({ event_id: eventId, user_id: profile.id, status: "invited" })

  if (participantError) {
    // Handle potential duplicate error gracefully
    if (participantError.code === "23505") {
      // unique_violation
      // This is not a critical error, just feedback to the user.
      console.log(`Player with phone ${playerPhone} already in event ${eventId}.`)
    } else {
      return { error: `Could not add participant: ${participantError.message}` }
    }
  }

  revalidatePath(`/events/${eventId}`)
  return { success: true }
}

export async function updateParticipantStatus(eventId: string, status: "joined" | "declined") {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { error: "User not found." }

  const { error } = await supabase
    .from("event_participants")
    .update({ status })
    .eq("event_id", eventId)
    .eq("user_id", user.id)

  if (error) return { error: "Could not update status." }

  revalidatePath(`/events/${eventId}`)
  return { success: true }
}

export async function leaveEvent(eventId: string) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { error: "User not found." }

  const { error } = await supabase.from("event_participants").delete().eq("event_id", eventId).eq("user_id", user.id)

  if (error) return { error: "Could not leave event." }

  revalidatePath(`/events/${eventId}`)
  return { success: true }
}

export async function updateDrawData(eventId: string, drawData: any) {
  const supabase = createClient()
  const { error } = await supabase.from("events").update({ draw_data: drawData }).eq("id", eventId)
  if (error) return { error: "Database error: Could not save draw." }
  revalidatePath(`/events/${eventId}`)
  return { success: true }
}
