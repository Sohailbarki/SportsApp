// Mock user data. In a real app, this would come from your database after login.
export const mockUser = {
  id: 'user_123',
  name: 'Alex',
  avatar: '/placeholder.svg?height=40&width=40',
};

// A larger list of users in the system to select from when creating an event.
export const allUsers = [
  { id: 'user_123', name: 'Alex' },
  { id: 'user_002', name: 'Bob' },
  { id: 'user_003', name: 'Charlie' },
  { id: 'user_004', name: 'Diana' },
  { id: 'user_005', name: 'Ethan' },
  { id: 'user_006', name: 'Fiona' },
  { id: 'user_007', name: 'George' },
  { id: 'user_008', name: 'Hannah' },
  { id: 'user_009', name: 'Ian' },
  { id: 'user_010', name: 'Julia' },
];

// A comprehensive list of sports for the dropdown.
export const allSports = [
  "Archery", "Athletics", "Badminton", "Baseball", "Basketball", "Beach Volleyball", "BMX", "Bocce", "Bodybuilding", "Bowling", "Boxing", "Canoeing / Kayaking", "Chess", "Cricket", "CrossFit", "Curling", "Cycling", "Darts", "Diving", "Dodgeball", "Dragon Boat", "Equestrian", "Esports", "Fencing", "Field Hockey", "Figure Skating", "Fishing (Sport)", "Floorball", "Football (Soccer)", "Futsal", "Gaelic Football", "Golf", "Gymnastics", "Handball", "Ice Hockey", "Jiu-Jitsu", "Judo", "Karate", "Kickboxing", "Korfball", "Lacrosse", "Martial Arts (Mixed)", "Modern Pentathlon", "Motorsport (Car Racing, Karting, etc.)", "Mountaineering", "Netball", "Orienteering", "Paddleboarding", "Paintball", "Paragliding", "Pickleball", "Pilates", "Polo", "Powerlifting", "Quidditch (Fantasy)", "Racketlon", "Rhythmic Gymnastics", "Rock Climbing", "Roller Skating / Roller Derby", "Rowing", "Rugby League", "Rugby Union", "Running (Track, Marathon, etc.)", "Sailing", "Shooting (Target, Clay, etc.)", "Skateboarding", "Skiing", "Snowboarding", "Softball", "Speed Skating", "Squash", "Surfing", "Swimming", "Table Tennis", "Taekwondo", "Tennis", "Trampolining", "Triathlon", "Ultimate Frisbee", "Volleyball", "Wakeboarding", "Walking (Race Walking)", "Water Polo", "Weightlifting", "Windsurfing", "Wrestling", "Yoga", "Zumba (Fitness Sport)"
].map(sport => ({ value: sport.toLowerCase().replace(/ /g, '-').replace(/\//g, '-'), label: sport }));

// Add "Other" option at the end
allSports.push({ value: 'other', label: 'Other (Custom)' });


// Mock event data
export const mockEvent = {
  id: '2',
  title: 'Padel Tournament',
  sport: 'Padel',
  location: 'Urban Padel Club',
  time: '2025-08-12T19:30:00Z',
  participants: [
    { id: 'p1', name: 'Team Alpha' },
    { id: 'p2', name: 'Team Bravo' },
    { id: 'p3', name: 'Team Charlie' },
    { id: 'p4', name: 'Team Delta' },
    { id: 'p5', name: 'Team Echo' },
    { id: 'p6', name: 'Team Foxtrot' },
  ],
  capacity: 16,
  description: 'Friendly knockout tournament. All levels welcome. Bring your own racket.',
  organizerId: 'user_123', // Alex is the organizer
};
