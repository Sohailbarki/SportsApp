type Participant = { id: string; name: string };
type Match = { p1: Participant | { name: string }; p2: Participant | { name: string } };

// --- Round Robin ---
// Generates all unique pairs for a round-robin tournament.
export function generateRoundRobin(participants: Participant[]): Match[] {
  const matches: Match[] = [];
  if (participants.length < 2) return [];

  for (let i = 0; i < participants.length; i++) {
    for (let j = i + 1; j < participants.length; j++) {
      matches.push({ p1: participants[i], p2: participants[j] });
    }
  }
  return matches;
}

// --- Knockout (Single Elimination) ---
// Generates the first round of a single-elimination tournament, handling byes.
export function generateSingleElimination(participants: Participant[], seeded = false): Match[] {
  let players = [...participants];
  if (!seeded) {
    // Shuffle players if not seeded for random pairings
    players.sort(() => Math.random() - 0.5);
  }

  const numPlayers = players.length;
  if (numPlayers < 2) return [];

  const nextPowerOfTwo = Math.pow(2, Math.ceil(Math.log2(numPlayers)));
  const byes = nextPowerOfTwo - numPlayers;
  const numMatches = (numPlayers - byes) / 2;

  const matches: Match[] = [];
  const playersWithByes = players.slice(0, byes).map(p => ({ ...p, isBye: true }));
  const playersInMatches = players.slice(byes);

  // Assign byes
  playersWithByes.forEach(player => {
    matches.push({ p1: player, p2: { name: 'BYE' } });
  });

  // Create matches for the first round
  for (let i = 0; i < numMatches; i++) {
    matches.push({ p1: playersInMatches[i], p2: playersInMatches[playersInMatches.length - 1 - i] });
  }

  return matches;
}

// Note: Double Elimination, Consolation, and Compass draws are more complex and would typically
// require tracking match results to generate subsequent rounds. This implementation
// generates the initial structure.

// --- Double Elimination ---
// The "winners" bracket is just a single elimination tournament.
export function generateDoubleElimination(participants: Participant[], seeded = false) {
  return {
    winnersBracket: generateSingleElimination(participants, seeded),
    losersBracket: [], // Losers bracket is populated as matches are played.
  };
}
